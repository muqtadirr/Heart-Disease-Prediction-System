export default function App(){ return <h1>Heart Disease Prediction System</h1> }
