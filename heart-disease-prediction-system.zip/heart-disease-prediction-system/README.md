# Heart Disease Prediction System

AI-powered healthcare prediction web app using React, Node.js, Flask, MongoDB, and Machine Learning.
